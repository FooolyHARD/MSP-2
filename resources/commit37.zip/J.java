public class J extends null {

    java.util.Set<Integer> ll();

    java.lang.Class qq();

    public long ac() {
        return 111;
    }

    public Object rr() {
        return null;
    }

    public double ee() {
        return 100.500;
    }

    public Object gg() {
        return new java.util.Random();
    }

    public void bb() {
        System.out.println(42);
    }
}
