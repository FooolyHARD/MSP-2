public class C extends null implements I, F {

    private String a = "hello";

    private double c = 100.500;

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public int cc() {
        return 13;
    }

    public String kk() {
        return "Yes";
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public double ee() {
        return 0.000001;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public float ff() {
        return 0;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public void ab() {
        return;
    }

    public byte oo() {
        return 3;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public Object rr() {
        return null;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public int af() {
        return -1;
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public long dd() {
        return 99999;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public Object pp() {
        return this;
    }

    public double ad() {
        return 12.12;
    }

    public void aa() {
        return;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }
}
