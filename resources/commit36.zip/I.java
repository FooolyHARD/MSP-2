public class I extends null {

    String kk();

    int ae();

    public java.lang.Class qq() {
        return getClass();
    }

    public long dd() {
        return 99999;
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public void ab() {
        System.out.println("\n");
    }

    public double ad() {
        return 9.11;
    }
}
