public class I extends null {

    String kk();

    int ae();

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public double ad() {
        return 11.09;
    }

    public java.lang.Class qq() {
        return getClass();
    }
}
