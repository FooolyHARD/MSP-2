public interface I {

    String kk();

    int ae();
}
