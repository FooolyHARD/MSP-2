public class J extends null {

    java.util.Set<Integer> ll();

    java.lang.Class qq();

    public int af() {
        return -1;
    }

    public byte oo() {
        return 4;
    }
}
