public class J extends null {

    java.util.Set<Integer> ll();

    java.lang.Class qq();

    public int af() {
        return -1;
    }

    public byte oo() {
        return 4;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }
}
