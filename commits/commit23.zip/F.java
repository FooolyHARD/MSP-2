public class F extends null {

    double ee();

    Object gg();
}
