public class I extends null {

    String kk();

    int ae();
}
