public class J extends null {

    java.util.Set<Integer> ll();

    java.lang.Class qq();
}
